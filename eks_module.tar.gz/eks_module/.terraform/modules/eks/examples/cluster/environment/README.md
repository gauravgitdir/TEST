This example provisions an environment that is used in the cluster example.
This is order that we can simulate using the module to launch a cluster using
IAM and VPC resources managed externally.
